% OUTPUTS FROM Easy_Volume
%
% ---- if only total volumes are computed
%      a matlab file called total [grey matter/white matter/csf] volumes is
%      created in the result directory you selected
%
%      once loaded results are in a variable called results such as if you
%      load the total [grey matter/white matter/csf] volume.mat file (either
%      right click --> load or in command line load name_of_the_file)
%      typing in the command window:
%      results{1} returns the files that were selected in the same order
%      results{2} returns the corresponding volumes in litres
%
% ---- if partial volumes are also computed
%      a matlab file called results_[grey_matter/white_matter/csf] is
%      created in the result directory you selected as well as your initial
%      images masked by the different masks you selected
%
%      once loaded results are in a variable called results such as if you
%      load the results_[grey matter/white matter/csf].mat file (either
%      right click --> load or in command line load nane_of_the_file)
%      typing in the command window:
%      results.subjects_name returns the files that were selected in the same order
%      results.total_[grey_matter/white_matter/csf]_volume returns the corresponding volumes in litres (type either grey_matter, or white_matter or csf)
%      results.partial_grey_matter_volume{1} is for the 1st region analyzed with
%      results.partial_grey_matter_volume{1}.roi_name = the name of the 1st mask (change to white oir csf if needed, update the number according to the mask you region you want)
%      results.partial_grey_matter_volume{1}.volumes = the volumes in the roi following subject's name
