function cp_compare_gps
% this function replicates cg_check_sample_sd
% at variance with the referenced function, the user has the choice between 
% computing the sum of squarre distance from the sample mean or from any 
% other image (e.g. template priors), the difference (2 sampe t-test)
% between 2 groups in then computed along with a graph
% cyril pernet 28/01/2008

%% get the data
P1 = spm_select(Inf,'image','Select images gp1');
V1 = spm_vol(P1);
n1 = size(P1,1);

if length(V1)>1 & any(any(diff(cat(1,V1.dim),1,1),1))
	error('images don''t all have same dimensions')
end
if any(any(any(diff(cat(3,V1.mat),1,3),3)))
	error('images don''t all have same orientation & voxel size')
end

P2 = spm_select(Inf,'image','Select images gp2');
V2 = spm_vol(P2);
n2 = size(P2,1);

if length(V2)>1 & any(any(diff(cat(1,V2.dim),1,1),1))
	error('images don''t all have same dimensions')
end
if any(any(any(diff(cat(3,V2.mat),1,3),3)))
	error('images don''t all have same orientation & voxel size')
end

% check compatibility between images of each gp
test = sum(cat(1,V1(1).dim) == cat(2,V1(1).dim));
if test ~=3
    error('images from gp1 and gp 2 are of different size')
end

%% compute distances
% ask for the target image to use (mean or another image)
target = spm_input('compute distance from the mean','-1','y/n');
if target == 'n'
    P3 = spm_select(1,'image','Select image to compute the distance from');
    V3 = spm_vol(P3);
    mean_data = spm_read_vols(V3);
else
    mean_data1 = zeros(V1(1).dim(1:3));
    spm_progress_bar('Init',n1,'read gp1');
    for i=1:n1
        vol = spm_read_vols(V1(i));
        mean_data1 = mean_data1 + vol/n1;
        spm_progress_bar('Set',i);
    end

    mean_data2 = zeros(V2(1).dim(1:3));
    spm_progress_bar('Init',n2,'read gp2');
    for i=1:n2
        vol = spm_read_vols(V2(i));
        mean_data2 = mean_data2 + vol/n2;
        spm_progress_bar('Set',i);
    end

    mean_data = (mean_data1 + mean_data2) / 2;
end

% compute the distances
std_data1  = zeros(V1(1).dim(1:3));
std_data2  = zeros(V2(1).dim(1:3));
squared_distance1 = zeros(n1,1);
squared_distance2 = zeros(n2,1);
mask = (mean_data ~= 0);
sz_mask = sum(mask(:));

n = n1+n2; entry = 0;
spm_progress_bar('Init',n,'compute distances');
for i=1:(n1+n2)
    if i<=n1
    vol = spm_read_vols(V1(i));
    dist1 = (mean_data(mask) - vol(mask)).^2;
    squared_distance1(i) = sum(dist1(~isnan(dist1)));
	spm_progress_bar('Set',i);    
    else
    entry = entry+1;    
    vol = spm_read_vols(V2(entry));
    dist2 = (mean_data(mask) - vol(mask)).^2;
    squared_distance2(entry) = sum(dist2(~isnan(dist2)));
	spm_progress_bar('Set',i);    
    end
end

spm_progress_bar('Clear');

%% finally do the 2 sample t-test and make a graph
% stat
df = n-2;
S = ((n1-1)*std(squared_distance1) + (n2-1)*std(squared_distance2)) / (df);
t = ((sum(squared_distance1)/n1)-(sum(squared_distance2)/n2)) / (S*sqrt((1/n1)+(1/n2)));
if target == 'y'
    p=tcdf(t,df)*2 % *2 because bilateral
else
    p = (1-tcdf(t,df))*2; 
end


if p<0.05
    if target == 'n'
        fprintf('groups have significant different mean distances from %s',P3); 
        disp(' ')
    else
        fprintf('groups have significant different mean distances from the mean image'); 
        disp(' ')
    end
else
    if target == 'n'
        fprintf('groups do not significantly differ from %s',P3); 
        disp(' ')
    else
        fprintf('groups do not significantly differ from the mean image'); 
        disp(' ')
    end
end
fprintf('t(%g)=%g p=%g',df,t,p)
disp('')

